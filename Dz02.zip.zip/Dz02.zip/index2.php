<?php
# 1
    class Animal {
        public $name;
    
    # 2
        public function __construct($name) {
            $this->name = $name;
        }

    # 3   
        public function eat() {
            return "Zwierzę je";
        } 
    }



    # 4
    class Cat extends Animal {
        public function eat() 
        {
            return "Zwierzę je";
        }
    
    }
    

    class Dog extends Animal {
        public function eat()
        {
            return "Zwierzę je";
        }
    
    }

    # 5

    $cat = new Cat("Niuniuś");
    $dog = new Dog("Sauron");
    echo $cat->eat();
    echo $dog->eat();
?>