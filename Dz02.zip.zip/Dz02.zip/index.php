<?php
    # 1

    class Vehicle {
        public $brand;

    public function __construct($brand)
    {
        $this->brand = $brand;
    }
    # 2
    public function move()
    {
        return "...";
    }

}
    # 3

    class Car extends Vehicle {
        public $model;

        public function __construct($brand, $model)
      {
          parent::__construct($brand);
          $this->model = $model;
      }

    # 4

      public function move()
      {
          return "";
      }
    }

    # 5
    class Truck extends Vehicle {
    public $color; 
    
    public function __construct($color) {
        $this->color = $color;
    }
}
?>