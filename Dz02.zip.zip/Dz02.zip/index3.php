<?
# 1
class Employee {
    public $name;
    protected $salary;

    public function __construct($name, $salary) {
        $this->name = $name;
        $this->salary = $salary;
    }

    public function showInfo() {
        return "Imię: $this->name, Pensja: $this->salary $";
    }
}

# ----
    # 4
    class Manager extends Employee {
        public $departament;

        public function __construct($name, $salary, $departament) {
            $this->departament = $departament;
            return parent::__construct($name,$salary);
        }
    }    
    
    # 5 Nadpisz metodę showInfo(), aby wyświetlała również dział.

    class Manager extends Employee {
        public $department;
    
        public function __construct($name, $salary, $department) {
            parent::__construct($name, $salary);
            $this->department = $department;
        }
    
        public function showInfo() {
            return " Dział: $this->department";
        }
    }
    
    $manager = new Manager("Mateusz", 6767, "IT");
    
    echo $manager->showInfo();


?>

<?php





?>