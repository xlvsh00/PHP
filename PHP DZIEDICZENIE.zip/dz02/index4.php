<?php

class Book
{
    public $title;
    public $author;

    public function __construct($title, $author)
    {
        $this->title = $title;
        $this->author = $author;
    }

    public function getInfo()
    {
        return "$this->title została napisana przez $this->author.";
    }
}

class Ebook extends Book {
    public $fileSize;

    public function __construct($title, $author, $fileSize)
    {
        parent::__construct($title, $author);
        $this->fileSize = $fileSize;

    }

    public function getInfo()
    {
        return "Rozmiar pliku to $this->fileSize MB.";
    }
}

$ebook = new Ebook("PHP dla początkujących", "Zbigniew Kucharski", 5);

echo $ebook->getInfo();


?>