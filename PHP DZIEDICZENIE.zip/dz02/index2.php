<?php
    class Animal {
        public $name;
    
        public function __construct($name) {
            $this->name = $name;
        }
  
        public function eat() {
            return "Zwierzę je";
        } 
    }



    class Cat extends Animal {
        public function eat() 
        {
            return "Zwierzę je";
        }
    
    }
    

    class Dog extends Animal {
        public function eat()
        {
            return "Zwierzę je";
        }
    
    }


    $cat = new Cat("Niuniuś");
    $dog = new Dog("Sauron");
    echo $cat->eat();
    echo $dog->eat();
?>