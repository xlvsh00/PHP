<?php

    class Vehicle {
        public $brand;

    public function __construct($brand)
    {
        $this->brand = $brand;
    }

    public function move()
    {
        return "...";
    }

}

    class Car extends Vehicle {
        public $model;

        public function __construct($brand, $model)
      {
          parent::__construct($brand);
          $this->model = $model;
      }

      public function move()
      {
          return "";
      }
    }

$car = new Car("Toyota" , "RWD");
echo $car->brand;


    if(is_a($car, 'Vechicle')) {
        echo ("Auto");
    }

    class Truck extends Vehicle {
    public $color; 
    
    public function __construct($color) {
        $this->color = $color;
    }
}
?>