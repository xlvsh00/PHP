<?php

class Notification
{
    public $message;

    public function __construct($message)
    {
        $this->message = $message;
    }

    public function send()
    {
        echo $this->message;
    }
}

class EmailNotification extends Notification
{
    private $email;

    public function __construct($message, $email)
    {
        parent::__construct($message);
        $this->email = $email;
    }

    public function send()
    {
        echo "Email do " . $this->email . ": " . $this->message;
    }
}

class SMSNotification extends Notification
{
    private $phoneNumber;

    public function __construct($message, $phoneNumber)
    {
        parent::__construct($message);
        $this->phoneNumber = $phoneNumber;
    }

    public function send()
    {
        echo "SMS na numer " . $this->phoneNumber . ": " . $this->message;
    }
}

$email = new EmailNotification("Hej!", "ok@example.com");
$sms = new SMSNotification("Hej!", "6767676767");

$email->send();
$sms->send();

?>