<?php

class Employee
{
    public $name;
    protected $salary;

    public function __construct($name, $salary)
    {
        $this->name = $name;
        $this->salary = $salary;
    }

    public function showInfo()
    {
        return "Imię: $this->name, Pensja: $this->salary $";
    }
}


class Manager extends Employee
{
    public $department;

    public function __construct($name, $salary, $department)
    {
        parent::__construct($name, $salary);
        $this->department = $department;
    }

    public function showInfo()
    {
        return " Dział: $this->department";
    }
}

$manager = new Manager("Mateusz", 6767, "IT");

echo $manager->showInfo();


?>
